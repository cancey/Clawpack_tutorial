
subroutine setprob

	implicit none

	character*12 fname
	integer iunit
	double precision rho, mu, grav
	common /rheology/ rho, mu, grav

	!
	!     # read data values for this problem
	!
	!
	iunit = 7
	fname = 'setprob.data'
	!     # open the unit with new routine from Clawpack 4.4 to skip over
	!     # comment lines starting with #:
	call opendatafile(iunit, fname)


	!     # These parameters are used in src2.f90
	read(7,*) rho
	read(7,*) mu
	read(7,*) grav
	close(unit=7)

	print *, 'rho = ',rho
	print *, 'mu  = ',mu
	print *, 'g   = ',grav




end subroutine setprob
