subroutine qinit(meqn,mbc,mx,xlower,dx,q,maux,aux)

    ! Set initial conditions for the q array.

    use geoclaw_module, only: sea_level
    use grid_module, only: xcell

    ! uncomment if any of these needed...
    use geoclaw_module, only: dry_tolerance, grav

    implicit none

    integer, intent(in) :: meqn,mbc,mx,maux
    real(kind=8), intent(in) :: xlower,dx
    real(kind=8), intent(in) :: aux(maux,1-mbc:mx+mbc)
    real(kind=8), intent(inout) :: q(meqn,1-mbc:mx+mbc)

    !locals
    integer :: i
    real(kind=8) :: x0, width, eta, x, xb, H0, theta

    x0 = 0.d0   ! initial location of step
    theta = 10d0*3.14159d0/180d0
    H0 = 1.d0
    xb = -50.d0
    
     

    do i=1,mx
      x = xlower +(i-0.5)*dx
      q(1,i) = 0.
      if (x <=0.d0 .and. x>=xb) then
		  q(1,i) = H0  
	  endif	  
      q(2,i) = 0.  ! right-going

   enddo


end subroutine qinit
