subroutine src2(meqn,mbc,mx,my,xlower,ylower,dx,dy,q,maux,aux,t,dt)
      
    !use geoclaw_module, only: g => grav
    !use module_rheology
 
 

    implicit none
    
    ! Input parameters
    integer, intent(in)          :: meqn,mbc,mx,my,maux
    double precision, intent(in) :: xlower,ylower,dx,dy,t,dt
    
    ! Output
    double precision, intent(inout) :: q(meqn,1-mbc:mx+mbc,1-mbc:my+mbc)
    double precision, intent(inout) :: aux(maux,1-mbc:mx+mbc,1-mbc:my+mbc)
    
    double precision  rho, n, p, mu, tau_c, d_0, theta, grav
	common /rheology/ rho, n, p, mu, tau_c, grav
	common /initial_depth/ d_0, theta
    ! Locals
    integer      :: i, j 
    real(kind=8) :: h, hu, hv, taurho, gamma
 
 
 

    ! Algorithm parameters
    ! Parameter controls when to zero out the momentum at a depth in the
    ! friction source term
    real(kind=8), parameter :: depth_tolerance = 1.0d-16

    ! Physics
    ! Nominal density of water
    ! real(kind=8), parameter :: rho = 1000.d0
    do j=1,my
            do i=1,mx
				h  = q(1,i,j)
				hu = q(2,i,j)
				hv = q(3,i,j)
				if (h<depth_tolerance) then
				    q(2,i,j) = 0.d0
					q(3,i,j) = 0.d0
				else
				    gamma = mu*dcos(theta)*grav*h/dsqrt(hu**2+hv**2)
					q(2,i,j) = q(2,i,j)/(1.d0+dt*gamma)
					q(3,i,j) = q(3,i,j)/(1.d0+dt*gamma)
				end if
					
			end do
	end do
 
 
     

end subroutine src2
