
"""
Module to create topo and qinit data files for this example.
"""

from __future__ import absolute_import
from clawpack.geoclaw.topotools import Topography
from numpy import *

def maketopo():
    """
    Output topography file for the entire domain
    """
    nxpoints = 2500
    nypoints = 20
    xlower = -500.e0
    xupper = 2500.e0
    yupper = 100.e0
    ylower = -100.e0
    outfile= "plane.topotype2"     

    topography = Topography(topo_func=topo)
    topography.x = linspace(xlower,xupper,nxpoints)
    topography.y = linspace(ylower,yupper,nypoints)
    topography.write(outfile, topo_type=2, Z_format="%22.15e")



def topo(x,y):
    """
    Parabolic bowl
    """
    # value of z at origin:  Try zmin = 80 for shoreline or 250 for no shore
    zmin = 0.
    pente = -0.02
    z = pente * x +1000.
    return z




if __name__=='__main__':
    maketopo()

