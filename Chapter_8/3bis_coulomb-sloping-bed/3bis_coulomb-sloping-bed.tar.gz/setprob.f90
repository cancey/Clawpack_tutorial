! setprob.f90 for AVAC 4: version = 1.1
      
      subroutine setprob
      implicit none
!     integer :: coulomb
      
      character*12 fname, free_surface
      integer iunit
      double precision rho, n, p, mu, theta, tau_c, d_0, x_b, grav
      common /rheology/ rho, n, p, mu, tau_c, grav
      common /initial_conditions/ free_surface
      common /initial_depth/ d_0, theta, x_b
       
!
!     # read data values for this problem
!
!
      iunit = 7
      fname = 'setprob.data'
!     # open the unit with new routine from Clawpack 4.4 to skip over
!     # comment lines starting with #:
      call opendatafile(iunit, fname)


!     # These parameters are used in src2.f90
      read(7,*) rho
      read(7,*) n
      read(7,*) p
      read(7,*) mu
      read(7,*) tau_c
!     # These parameters are used in qinit.f90
      read(7,*) theta
      read(7,*) free_surface
      read(7,*) d_0
      read(7,*) x_b
      read(7,*) grav
 

      close(unit=7)
      print *, 'rho = ',rho
      print *, 'n   = ',n
      print *, 'p   = ',p
      print *, 'mu  = ',mu
      print *, 'g  = ',grav
      print *, 'theta = ',theta
      print *, 'tau_c = ',tau_c
      print *, 'd0 = ',d_0
      print *, 'xb = ',x_b
      print *, 'type of free surface: ',free_surface
!      if (coulomb == 0) then
!		print *, 'model = voellmy'
!      else
!		print *, 'model = coulomb'
!      endif
 
      end subroutine setprob
 
 


