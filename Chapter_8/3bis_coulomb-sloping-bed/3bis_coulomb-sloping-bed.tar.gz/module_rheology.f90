module module_rheology
    implicit none
    
    contains
    function friction(h,hu,hv,mu,n,p,theta,tau,g,rho)
			implicit none
			real(kind=8), intent(in)  :: h,hu,hv,mu,n,p,theta,tau,g,rho 
			real(kind=8)              :: q
			real(kind=8)              :: friction
			real(kind=8), parameter   :: depth_tolerance = 1.0d-30
			q = dsqrt(hu**2+hv**2)
			if (h>depth_tolerance) then
				friction = rho*g*(mu*h*cos(theta) +q**2/h**(p+2)*n)+tau
			else
				friction = 0.d0
			end if
	end function friction
	
   function norm_f(h,hu,hv,mu,n,p,theta,tau,g,rho)
			implicit none
			real(kind=8), intent(in)  :: h,hu,hv,mu,n,p,theta,tau,g,rho 
			real(kind=8)              :: q
			real(kind=8)              :: norm_f
			real(kind=8), parameter   :: q_tolerance = 1.0d-16
			q = dsqrt(hu**2+hv**2)
			if (q>q_tolerance) then
				norm_f = friction(h,hu,hv,mu,n,p,theta,tau,g,rho)/rho/q
			else
				norm_f = 0.d0
			end if
	end function norm_f
    
end module module_rheology
