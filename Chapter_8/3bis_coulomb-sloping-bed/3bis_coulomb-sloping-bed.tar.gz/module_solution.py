from scipy.special import hyp2f1
from scipy.integrate import quad, dblquad, nquad
import numpy as np
from scipy.special import hyp2f1
from scipy.integrate import quad, dblquad
from functools import lru_cache
from scipy.optimize import root
from scipy.optimize import brentq
from tqdm import tqdm

def sol_A(t):
    """ front position """
    return np.where(t < 2, 
                   2*t- t**2/2, 
                   2)
  


def sol_B(t):
    """ back front position """
    # x_b = 3.4779*(1+t/2)-0.664*(1+t/2)**2-0.09623*(1+t/2)**3+0.034475*(1+t/2)**4
    # x_b = 3.6223453807945707 -5.400559537999306* (1+t/2)+ \
    #     2.0222717471071308* (1+t/2)**2-0.4080853695712823* (1+t/2)**3+0.26528651975070405* (1+t/2)**4-\
    #     0.130774316010968* (1+t/2)**5+0.033614410186182296* (1+t/2)**6-0.004098834257031028* (1+t/2)**7
    b = 0.5*t+1
    #return -(-3.504283333333333 + 4.9558*b - 1.328*b**2 - 0.19246666666666667*b**3 + 0.06895*b**4)
    x_b =  -(-3.64928+5.47993*b-2.06989* b**2+0.319976* b**3-0.103745 *b**4+0.0230073* b**5)
    return np.where(t < 1.529654, 
                   x_b, 
                   -0.721)


 
#====================================
@lru_cache(maxsize=None)  # Cache for repeated calls
def Riemann(s, r, a, b):
    """ Riemann function (8.79)."""
    try:
        denominator = (a + r)**1.5 * (s + b)**1.5
    except FloatingPointError:
        return 0.0
    c = (r + s)**3 / denominator
    z = ((r - b) * (s-a)) / ((r+a) * (s+b))
    if np.isnan(z) or abs(z) >= 1.0:  # for hyp2f1 convergence condition
        return 0.0
    return c * hyp2f1(1.5, 1.5, 1, z)



def t_r(r):
    """ approximation of t_r, eq. (8.99)"""
    approx = 3.700279768999653  -2.0222717471071308* r+0.6121280543569234* r**2-0.5305730395014081*\
          r**3+0.32693579002742174* r**4-0.1008432305585469* r**5+0.014345919899608602* r**6
    return approx

def Riemann_s(s,r,a,b):
    """ s-derivative of the Riemann function """
    z    = ((r - b) * (s-a)) / ((r+a) * (s+b))
    aux1 = hyp2f1(1.5, 1.5, 1, z)
    aux2 = hyp2f1(2.5, 2.5, 2, z)
    aux3 =((r+s)**3.)*(((((r-b)/(b+s))/(a+r))-(((r-b)*((s-a)*((b+s)**-2.)))/(a+r)))*aux2)
    aux4 = (-1.5*(((a+r)**-1.5)*(((b+s)**-2.5)*(((r+s)**3.)*aux1))))+(2.25*(((a+r)**-1.5)*(((b+s)**-1.5)*aux3)))
    output=(3.*(((a+r)**-1.5)*(((b+s)**-1.5)*((((r+s)**2))*aux1))))+aux4
    if np.isnan(z) or abs(z) >= 1.0:  # hyp2f1 convergence condition
        return 0.0
    return output

def Riemann_r(s,r,a,b):
    """ r-derivative of the Riemann function """
    z    = ((r - b) * (s-a)) / ((r+a) * (s+b))
    aux1 = hyp2f1(1.5, 1.5, 1, z)
    aux2 = hyp2f1(2.5, 2.5, 2, z)
    aux3=((r+s)**3.)*(((((s-a)/(b+s))/(a+r))-((((a+r)**-2.)*((r-b)*(s-a)))/(b+s)))*aux2) 
    aux4=(-1.5*(((a+r)**-2.5)*(((b+s)**-1.5)*(((r+s)**3.)*aux1))))+(2.25*(((a+r)**-1.5)*(((b+s)**-1.5)*aux3))) 
    output=(3.*(((a+r)**-1.5)*(((b+s)**-1.5)*((((r+s)**2))*aux1))))+aux4 
    if np.isnan(z) or abs(z) >= 1.0:  # hyp2f1 convergence condition
        return 0.0
    return output

def meanRrs(r,a,b):
    """ 
    this function gives (Riemann_r+Riemann_s)/2 along s = r-2  
    by using it we avoid the singularity in aux4 in Riemann_r andRiemann_s
    """
    z =  (((b-r)*(-2.+(a+r)))/(a+r))/((2.+b)-r)
    aux0 = hyp2f1(1.5,1.5,1,z)
    aux1=(-2.+(a+((-3.*b)+((2.*(a*b))+((2.*(((2.+b)-a)*r))+(-2.*(r**2)))))))*aux0
    aux2 = hyp2f1(1.5,2.5,1,z)

    aux3=(((2.+b)-r)*((a+r)*aux1))+(-2.*((a+b)*((((-2.+(a+((a*b)+(((2.+b)-a)*r))))-(r**2))-b)*aux2)))

    if not np.isfinite(aux1): return 0.0
    if not np.isfinite(aux2): return 0.0
    tol = 1e-12
    denom = b - r
    if abs(denom) < tol:
        denom = np.sign(denom) * tol  # avoid division by 0
    if (2 + b - r) <= 0 or (a + r) <= 0 or (b - r) == 0 or not np.isfinite(aux3):
        return 0.0

    output=((6.*((((2.+b)-r)**-2.5)*(((a+r)**-2.5)*aux3)))/(-2.+(a+r)))/denom
    if np.isnan(output) or abs(z) >= 1.0:  # for hyp2f1 convergence condition
        return 0.0
    return output

 

def B(r,a,b):
    """ operator B given by Eq. (8.91) """
    R   = Riemann(2-r,r,a,b)
    #fnc = R*(3*r-4+t_r(r))-(Riemann_s(2-r,r,a,b)+Riemann_r(2-r,r,a,b))*(r-1)
    fnc = R*(3*r-4+t_r(r))-meanRrs(r,a,b)*(r-1)*2
    return fnc

def TRiemann(a,b, eps=1e-9, limit=5000):
    """Compute the dimensionless time given by Eq. (8.99)"""
    def integrand(x):
        return B(x,a,b)
    
    # Handle potential singularities at integration bounds
    result, _ = quad(integrand, 1 + eps, b, 
                    limit=limit, 
                    #points=[2 + eps, r],
                    epsabs=1e-6, 
                    epsrel=1e-6)
    output = (b-1)*Riemann(2-b,b,a,b) + result
    return output

@lru_cache(maxsize=None)  # Cache for repeated calls
def XSRiemann(a, b,  eps=1e-6, limit=5000):
    """dimensionless position x given by Eq. (8.103)"""
    # Compute c1 term
    def TRiemann_integrand(x):
        return TRiemann(a,x)
    
    aux1 = -0.5 * quad(
        TRiemann_integrand, 1,b,
        limit=limit, epsabs=1e-5, epsrel=1e-5)[0] 
    
    aux2 = (b-3*a)/2*TRiemann(a,b)

    aux3 = -0.5*TRiemann(a,b)**2
    
    return aux1 + aux2 + aux3

def r_FB(s):
    """ equation for the FB curve given by Eq. (8.104) in the r-s plane"""
    r = 1.544 + 0.871*s + 0.273*s**2 + 0.029*s**3 + 0.090*s**4 + 0.010*s**5
    return r

 
def position(s,r):
    """Vectorizable position function corresponding to Fig. 8.8"""
    if (r < 1) or (r > 2):
        return np.nan
    elif (s < -1) or (s > 1):
        return np.nan
    elif ( r < r_FB(s)) and (r>1) and (s<1.76571):
        return XSRiemann(s,r)
    elif ( s > 1.76571) and (r>1) and (r<2-s):
        return XSRiemann(s,r)
    else:
        return 0.0

def temps(s,r):
    if r+s == 2:
        return 2*(r-1)
    elif (r < 1) or (r > 2):
        return np.nan
    elif (s < -1) or (s > 1):
        return np.nan
    elif ( r < r_FB(s)) and (r>1) and (s<1.76571):
        return TRiemann(s,r)
    elif ( s > 1.76571) and (r>1) and (r<2-s):
        return TRiemann(s,r)
    else:
        return 0.0
    


def solution_h_u(liste_temps,T0,ϵ = 1e-5,step = 5.e-3):
    """Provide the solution"""
    tps = liste_temps/T0



    s_min, s_max = -1 + ϵ, 1 - ϵ
    recap_xu, recap_xh, recap_u, recap_h = [], [], [], []

    def solve_root(ss, tt):
        sol = root(lambda r: temps(ss, r[0]) - tt, x0=[(ss + 2)/2])
        return sol.x[0] if sol.success else np.nan  # Ensure scalar output

    def solve_brentq(ss, tt):
        sol = brentq(lambda r: temps(ss,r) - tt,r_FB(ss),2-ss)
        return sol 

    def solve_root(ss, tt):
        def f_r(r):
            try:
                val = TRiemann(ss, r) - tt
                return val if np.isfinite(val) else np.nan
            except:
                return np.nan
        
        # Plage sûre pour r : entre 1 et 1.7657
        r_min = 1.0
        r_max = 1.7657  # à ajuster légèrement si besoin

        try:
            # On vérifie d'abord que la racine est bien encadrée
            if np.sign(f_r(r_min)) * np.sign(f_r(r_max)) < 0:
                sol = brentq(f_r, r_min, r_max, xtol=1e-10)
                return sol
            else:
                #print(f"Avertissement : pas de changement de signe pour ss={ss}, tt={tt}")
                return np.nan
        except Exception as e:
            print(f"Échec brentq pour ss={ss}, tt={tt}, erreur : {e}")
            return np.nan

    for tt in tqdm(tps):
        #s_values = np.linspace(s_min, s_max, 40)
        s_values = np.arange(s_min, s_max+step, step)
        r_values = np.array([solve_root(ss, tt) for ss in s_values])  # solve the implicit equation

        valid = ~np.isnan(r_values)
        s_values = s_values[valid]
        r_values = r_values[valid]
        
        solutions_x = np.array([XSRiemann(s,r)  for r, s in zip(r_values, s_values)])
        solutions_u = np.array(r_values-s_values    - tt )
        solutions_h = np.array((r_values + s_values)**2 / 4)

        solutions_xh = solutions_x[(solutions_h<=1) & (solutions_x<=2*tt-tt**2/2)]
        solutions_h = solutions_h[(solutions_h<=1) & (solutions_x<=2*tt-tt**2/2)]
        solutions_xu = solutions_x[(solutions_u>0) & (solutions_x<=2*tt-tt**2/2)]
        solutions_u = solutions_u[(solutions_u>0) & (solutions_x<=2*tt-tt**2/2)]


        recap_xu.append(solutions_xu)
        recap_xh.append(solutions_xh)
        recap_u.append(solutions_u)
        recap_h.append(solutions_h)
    return [solutions_xu,solutions_xh,solutions_u,solutions_h]