module module_rheology
    implicit none
   
    contains
    function friction(h,hu,hv)
			implicit none
			real(kind=8)              :: q
			real(kind=8)              :: friction
			real(kind=8), intent(in)  :: h,hu,hv
			double precision  rho, n, g, grav, depth_tolerance, square_u
	        common /rheology/ rho, n, grav, depth_tolerance
			q = dsqrt(hu**2+hv**2)
			g = grav
			if (h>depth_tolerance) then
			    square_u = q**2/h**2
				friction = rho*g*n**2*square_u/h**(1.d0/3.d0)
			else
				friction = 0.d0
			end if
	end function friction
	
   function norm_f(h,hu,hv)
			implicit none
			real(kind=8), intent(in)  :: h,hu,hv
			real(kind=8)              :: q
			real(kind=8)              :: norm_f
			double precision  rho, n, d_0, theta, grav, depth_tolerance, q_tolerance, g
	        common /rheology/ rho, n, grav, depth_tolerance
	        g = grav
	        q_tolerance = depth_tolerance*dsqrt(g*depth_tolerance)
			q = dsqrt(hu**2+hv**2)
			if (q>q_tolerance) then
				norm_f = friction(h,hu,hv)/rho/q/g
			else
				norm_f = 0.d0
			end if
	end function norm_f
    
end module module_rheology
