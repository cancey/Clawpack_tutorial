! setprob.f90 for AVAC 4: version = 1.1
      
      subroutine setprob
      implicit none
!     integer :: coulomb
      
      character*12 fname, free_surface
      integer iunit
      double precision rho, n, theta, d_0, x_b, grav, depth_tolerance
      common /rheology/ rho, n,  grav, depth_tolerance
      common /initial_conditions/ free_surface
      common /initial_depth/ d_0, theta, x_b
       
!
!     # read data values for this problem
!
!
      iunit = 7
      fname = 'setprob.data'
!     # open the unit with new routine from Clawpack 4.4 to skip over
!     # comment lines starting with #:
      call opendatafile(iunit, fname)


!     # These parameters are used in src2.f90
      read(7,*) rho
      read(7,*) n
!     # These parameters are used in qinit.f90
      read(7,*) theta
      read(7,*) free_surface
      read(7,*) d_0
      read(7,*) x_b
      read(7,*) grav
      read(7,*) depth_tolerance
 

      close(unit=7)
      print *, 'rho = ',rho
      print *, 'n   = ',n
      print *, 'g  = ',grav
      print *, 'theta = ',theta
      print *, 'd0 = ',d_0
      print *, 'xb = ',x_b
      print *, 'type of free surface: ',free_surface
      print *, 'dry limit = ',depth_tolerance
!      if (coulomb == 0) then
!		print *, 'model = voellmy'
!      else
!		print *, 'model = coulomb'
!      endif
 
      end subroutine setprob
 



