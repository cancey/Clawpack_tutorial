from scipy.special import hyp2f1
from scipy.integrate import quad, dblquad, nquad
import numpy as np
from scipy.special import hyp2f1
from scipy.integrate import quad, dblquad
from functools import lru_cache
from scipy.optimize import root
from scipy.optimize import brentq
from tqdm import tqdm

def sol_A(t,θ):
    """ front position """
    return 2*t+np.tan(θ)* t**2/2


def sol_B(t,θ):
    """ back front position """
    tb = 2/np.tan(θ)
    return np.where(t < tb, 
                   -t + (t**2/4)*np.tan(θ), 
                   -2*t + (t**2/2)*np.tan(θ) + 1/np.tan(θ))


 
# ================== CORE FUNCTIONS (OPTIMIZED) ==================
@lru_cache(maxsize=None)  # Cache for repeated calls
def Riemann(r, s, x, y):
    """Optimized Riemann function with safeguards."""
    denominator = (r - y)**1.5 * (x - s)**1.5
    if denominator == 0:
        return 0.0
    c = (r - s)**3 / denominator
    z = ((r - x) * (y - s)) / ((-s + x) * (r - y))
    if np.isnan(z) or abs(z) >= 1.0:  # hyp2f1 convergence condition
        return 0.0
    return c * hyp2f1(1.5, 1.5, 1, z)

@lru_cache(maxsize=None)  # Cache for repeated calls
def XSRiemann(rr, ss, θ, eps=1e-4, limit=1000):
    """Optimized XSRiemann with proper integrand definition."""
    # Compute c1 term
    def TRiemann_integrand(x):
        return Riemann(x, -2, rr, ss) * (2 - 5*x) / (4 * (x + 2))
    
    c1 = (3*ss + rr) * quad(
        TRiemann_integrand, 2 + eps, rr,
        limit=limit, epsabs=1e-5, epsrel=1e-5)[0] / (4 * np.tan(θ))
    

    # Compute c2 term with properly scoped integrand
    def c2_integrand(x, r):
        return Riemann(x, -2, r, ss) * (2 - 5*x) / (4 * (x + 2)) * (x > r)
    
    c2, _ = dblquad(
        c2_integrand,
        rr, 2 - eps,  # r limits
        lambda r: max(2 + eps, r), lambda r: rr,  # x limits
        epsabs=1e-5, epsrel=1e-5)
    
    return c1 + c2 / (4 * np.tan(θ))

# ================== POSITION FUNCTION (VECTORIZED) ==================
def position(r, s, θ):
    """Vectorizable position function with all edge cases."""
    if s == -2:
        return 1/16 * (-2 + r) * (8 + (-2 + r) * np.tan(θ))
    elif (r == s) and (s > -2):
        return 0.0
    elif (r < -2) or (r >= 2):
        return np.nan
    elif s > r:
        return 0.0
    elif (-2 < s < r < 2):
        return XSRiemann(r, s, θ)
    else:
        return 0.0

# Vectorized version for array inputs
vposition = np.vectorize(position, excluded=['θ'])

def TRiemann(r, s, θ, eps=1e-4, limit=1000):
    """Compute the T-Riemann integral with singularity handling."""
    def integrand(x):
        return Riemann(x, -2, r, s) * (2 - 5*x) / (4 * (x + 2))
    
    # Handle potential singularities at integration bounds
    result, _ = quad(integrand, 2 + eps, r, 
                    limit=limit, 
                    points=[2 + eps, r],
                    epsabs=1e-6, 
                    epsrel=1e-6)
    return np.real(result) / np.tan(θ)


def temps(r, s, θ):
    if not np.isscalar(r):
        r = r.item()  # Extract scalar if r is a 0D array
    if (s > -2) and (s < r) and (r < 2) and (r > -2):
        return TRiemann(r, s, θ)
    else:
        return 0
    


def solution_h_u(liste_temps,T0,θ,ϵ = 1e-2,step = 5.e-3):
    """Provide the solution"""
    tps = liste_temps/T0

    s_min, s_max = -2 + ϵ, 2 - ϵ
    recap_x, recap_u, recap_h = [], [], []

    def solve_r(ss, tt, θ):
        sol = root(lambda r: temps(r, ss, θ) - tt, x0=(ss + 2)/2, method='lm')
        return sol.x[0] if sol.success else np.nan  # Ensure scalar output

    for tt in tqdm(tps):
        s_values = np.linspace(s_min, s_max, 40)
        r_values = np.array([solve_r(ss, tt, θ) for ss in s_values])  # Convert to 1D array
        
        # Filter out solutions with NaN
        valid = ~np.isnan(r_values)
        s_values = s_values[valid]
        r_values = r_values[valid]
        
        solutions_x = [position(r, s, θ) + tt**2/2 * np.tan(θ) for r, s in zip(r_values, s_values)]
        solutions_u = (s_values + r_values)/2 + tt * np.tan(θ)
        solutions_h = (r_values - s_values)**2 / 16
        
        # Append boundary points
        solutions_x = np.append(solutions_x, 2*tt + tt**2/2 * np.tan(θ))
        solutions_u = np.append(solutions_u, 2 + tt * np.tan(θ))
        solutions_h = np.append(solutions_h, 0)
        
        if tt > 2/np.tan(θ):
            solutions_x = np.insert(solutions_x, 0, -2*tt + tt**2/2 * np.tan(θ) + 1/np.tan(θ))
            solutions_u = np.insert(solutions_u, 0, -2 + tt * np.tan(θ))
            solutions_h = np.insert(solutions_h, 0, 0)
        
    recap_x.append(solutions_x)
    recap_u.append(solutions_u)
    recap_h.append(solutions_h)



    return [solutions_x,solutions_u,solutions_h]
